-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `libraries`
--

DROP TABLE IF EXISTS `libraries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libraries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `player_id` int DEFAULT NULL,
  `game_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `libraries_to_players_idx` (`player_id`),
  KEY `libraries_to_games_idx` (`game_id`),
  CONSTRAINT `libraries_to_games` FOREIGN KEY (`game_id`) REFERENCES `video_games` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `libraries_to_players` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libraries`
--

LOCK TABLES `libraries` WRITE;
/*!40000 ALTER TABLE `libraries` DISABLE KEYS */;
INSERT INTO `libraries` VALUES (1,1,24),(2,1,25),(3,1,4),(4,1,17),(5,1,21),(6,1,5),(7,2,14),(8,2,10),(9,2,3),(10,2,13),(11,2,2),(12,3,19),(13,3,13),(14,3,4),(15,3,5),(16,3,12),(17,4,4),(18,4,6),(19,4,15),(20,5,25),(21,5,9),(22,5,17),(23,5,7),(24,5,21),(25,6,24),(26,6,1),(27,6,9),(28,6,12),(29,6,18),(30,6,10),(31,7,23),(32,7,24),(33,7,22),(34,7,14),(35,8,6),(36,8,19),(37,8,25),(38,8,15),(39,9,6),(40,9,17),(41,9,15),(42,9,22),(43,9,10),(44,10,23),(45,10,5),(46,10,8),(47,10,22),(48,10,10),(49,11,3),(50,11,9),(51,11,7),(52,11,22),(53,11,18),(54,12,19),(55,12,16),(56,12,22),(57,12,12),(58,12,20),(59,13,9),(60,13,18),(61,13,12),(62,13,5),(63,13,13),(64,13,24),(65,14,24),(66,14,6),(67,14,8),(68,14,19),(69,14,20),(70,15,20),(71,15,14),(72,15,8),(73,15,25),(74,16,17),(75,16,16),(76,16,25),(77,16,2),(78,17,7),(79,17,13),(80,17,20),(81,17,9),(82,17,23),(83,18,25),(84,18,8),(85,18,15),(86,19,12),(87,19,3),(88,19,1),(89,19,21),(90,19,25),(91,20,22),(92,20,17),(93,20,18),(94,21,22),(95,21,5),(96,21,8),(97,21,26),(98,22,5),(99,22,13),(100,22,23),(101,22,25),(102,22,7),(103,23,8),(104,23,24),(105,23,20),(106,23,2),(107,23,25),(108,24,24),(109,24,21),(110,24,8),(111,24,23),(112,24,15),(113,25,20),(114,25,13),(115,25,5),(116,25,9),(117,26,10),(118,26,26),(119,26,23),(120,26,8),(121,26,14),(122,27,6),(123,27,19),(124,27,24),(125,27,15),(126,28,19),(127,28,8),(128,28,6),(129,28,18),(130,29,8),(131,29,4),(132,29,21),(133,30,9),(134,30,6),(135,30,26),(136,30,11),(137,31,6),(138,31,20),(139,31,7),(140,31,22),(141,32,14),(142,32,9),(143,32,26),(144,32,2),(145,32,7);
/*!40000 ALTER TABLE `libraries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-22 19:24:37
